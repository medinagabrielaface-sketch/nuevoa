<?php
    echo '<meta http-equiv="Refresh" content="0; url=\'https://www.google.com\'" />';