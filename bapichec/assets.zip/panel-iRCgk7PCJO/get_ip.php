<?php
require_once('vendor/autoload.php');

use Src\App\Main;
use Src\Config\Header;

Header::load();

$main = new Main();
echo $main->getIp();